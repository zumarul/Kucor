<h1>Website Tembak Paket XL</h1>

silahkan gunakan di website anda, tinggal upload di public_html, untuk menambahkan id service di bagian tembak.php dan index.php, yang penting harus ngerti dulu tentang php dan HTML ;) sekian terimakasih
